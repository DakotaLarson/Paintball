package me.theredbaron24.paintball.utils;

public enum GameStatus {
	NOT_STARTED, COUNTING_DOWN, INITIALIZING, RUNNING, FINALIZING
}
