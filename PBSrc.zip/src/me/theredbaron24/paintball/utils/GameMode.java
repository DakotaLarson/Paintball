package me.theredbaron24.paintball.utils;

public enum GameMode {
	TDM, CTF, RTF, ELM;
}